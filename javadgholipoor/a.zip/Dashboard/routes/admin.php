<?php
Route::get('/', 'DashboardController@index')->name('dashboard');

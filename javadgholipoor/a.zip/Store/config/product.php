<?php

return [
    
    'types' => [
        'postal' => [
            'title' => 'پستی'
        ],
        'download' => [
            'title' => 'دانلودی'
        ],
        'virtual' => [
            'title' => 'مجازی'
        ]
    ]
    
];

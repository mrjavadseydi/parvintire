<?php

function taxes() {
    return \LaraBase\Store\Models\Tax::all();
}

<?php

function shipping() {
    return \LaraBase\Store\Models\Shipping::all();
}

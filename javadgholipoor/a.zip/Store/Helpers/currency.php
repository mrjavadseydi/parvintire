<?php

function getCurrencies() {
    return \LaraBase\Store\Models\Currency::all();
}

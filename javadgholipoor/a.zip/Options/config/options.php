<?php

return [
    
    'onOff' => [
        'sendTicketMail' => [
            'title' => '',
            'value' => true
        ],
        'sendTicketSms' => [
            'title' => '',
            'value' => false
        ],
    ]
    
];

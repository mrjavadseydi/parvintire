<?php
Route::post('addNewsLetters', 'NewsLettersController@store')->name('addNewsLetters');

<?php
Route::resource('transactions', 'TransactionController');

<?php

namespace LaraBase\Auth\Actions;

use Illuminate\Contracts\Auth\Access\Gate;

trait Authorizable
{

    /**
     * Determine if the entity has a given ability.
     *
     * @param  string  $ability
     * @param  array|mixed  $arguments
     * @return bool
     */
    public function can($ability, $arguments = [])
    {
        $permissions = $this->permissions();
        if (in_array($ability, $permissions))
            return true;

        return false;
    }

    /**
     * Determine if the entity does not have a given ability.
     *
     * @param  string  $ability
     * @param  array|mixed  $arguments
     * @return bool
     */
    public function cant($ability, $arguments = [])
    {

        $permissions = $this->permissions();
        if (in_array($ability, $permissions))
            return false;

        return true;
    }

    /**
     * Determine if the entity does not have a given ability.
     *
     * @param  string  $ability
     * @param  array|mixed  $arguments
     * @return bool
     */
    public function cannot($ability, $arguments = [])
    {
        return $this->cant($ability, $arguments);
    }
}

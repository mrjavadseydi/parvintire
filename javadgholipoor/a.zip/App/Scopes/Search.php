<?php

namespace LaraBase\App\Scopes;

trait Search
{

}

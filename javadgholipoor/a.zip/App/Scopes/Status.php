<?php

namespace LaraBase\App\Scopes;

trait Status
{

}

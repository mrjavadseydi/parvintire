<?php

return [
    'ir',
    'com',
    'net',
    'org',
    'biz',
    'info',
    'co',
    'me',
    'club',
    'mobi',
    'cc',
    'tv',
    'center',
    'zone',
    'company',
    'city',
    'click',
    'vip',
    'download',
];

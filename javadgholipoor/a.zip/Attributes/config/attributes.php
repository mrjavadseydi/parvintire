<?php

return [
    
    'type' => [
        'post' => [
            'title' => 'مطالب'
        ],
        'product' => [
            'title' => 'محصولات'
        ],
        'comment' => [
            'title' => 'نظرسنجی'
        ],
    ]
    
];

<?php

namespace LaraBase\World\models;

use LaraBase\CoreModel;

class Country extends CoreModel {
 
    protected $table = 'countries';
    
}

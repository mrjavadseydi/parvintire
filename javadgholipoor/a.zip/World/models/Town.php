<?php

namespace LaraBase\World\models;

use LaraBase\CoreModel;

class Town extends CoreModel {
    
    protected $table = 'towns';
    
}

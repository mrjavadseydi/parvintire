<?php

namespace LaraBase\World\models;

use LaraBase\CoreModel;

class Shingle extends CoreModel {
    
    protected $table = 'shingles';
    
}

<?php

namespace LaraBase\World\models;

use LaraBase\CoreModel;

class Province extends CoreModel {
    
    protected $table = 'provinces';
    
}

<?php

namespace LaraBase\World\models;

use LaraBase\CoreModel;

class WorldMeta extends CoreModel {

    protected $table = 'world_metas';
    
}

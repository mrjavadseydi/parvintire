<?php

namespace LaraBase\World\models;

use LaraBase\CoreModel;

class City extends CoreModel {
    
    protected $table = 'cities';
    
}

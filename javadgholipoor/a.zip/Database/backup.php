<?php

// TODO mysql backup code
/*
 mysqldump -uict24_controlpan -p'^+x6Pwau~S&3LQ3;*$-FkD(f' ict24_controlpanel | gzip > /home/tickettour/backup/backup-`date +"\%Y-\%m-\%d-\%H-\%M"`.sql.gz && /usr/local/bin/php /home/tickettour/public_html/system/cronjob/mysql-backup.php
 */

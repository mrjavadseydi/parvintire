<?php
Route::post('addComment', 'CommentController@store')->name('addComment');

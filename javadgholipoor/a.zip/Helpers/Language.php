<?php
namespace Larabase\Helper;

class Language
{

}

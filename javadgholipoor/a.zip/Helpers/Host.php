<?php
namespace Larabase\Helper;

class Host
{

}

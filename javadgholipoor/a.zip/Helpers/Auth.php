<?php

namespace LaraBase\Helpers;

class Auth {



}

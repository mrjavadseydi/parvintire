<?php


namespace LaraBase\Posts\Models;


use LaraBase\CoreModel;

class PostTag extends CoreModel {
    
    protected $table = 'post_tag';
    
}

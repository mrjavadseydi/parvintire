<?php

namespace LaraBase\Posts\Models;

use LaraBase\CoreModel;

class PostCategory extends CoreModel {
    
    protected $table = 'post_category';
    
}

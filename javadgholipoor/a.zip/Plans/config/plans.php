<?php

return [
    'types' => [
        'attribute' => [
            'title' => 'ویژگی'
        ],
        'file' => [
            'file' => 'فایل'
        ],
    ]
];
